<?php
// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "gharpayy";

//details for gharpayy database 
$servername = "localhost";
$username = "gharpayy_pg";
$password = "eQKL.2-GA3p[";
$dbname = "gharpayy_queries";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

?>